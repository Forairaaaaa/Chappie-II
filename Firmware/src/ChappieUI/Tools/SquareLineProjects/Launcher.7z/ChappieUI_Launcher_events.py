
def MenuIconUpdate(event_struct):
    return


def ClockPanelClicked(event_struct):
    return


def AppIconClicked(event_struct):
    return


def AppListValueChanged(event_struct):
    return

